package edu.unisabana.pizzafactory.consoleview;

import edu.unisabana.pizzafactory.model.*;
import edu.unisabana.pizzafactory.Fabricas.*;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PreparadorPizza {

    public static void main(String[] args) {
        try {
            Ingrediente[] ingredientes = new Ingrediente[]{
                new Ingrediente("queso", 1, "lácteo", "rebanadas"),
                new Ingrediente("jamón", 2, "proteína", "rebanadas"),
                new Ingrediente("pepperoni", 15, "embutido", "rodajas"),
                new Ingrediente("vegetales", 50, "vegetal", "gramos")
            };


            PreparadorPizza pp = new PreparadorPizza();

            // Aquí escoges la fábrica que quieres usar
            FabricaPizza fabrica = new FabricaPizzaDelgada();
            pp.prepararPizza(fabrica, ingredientes);

        } catch (ExcepcionParametrosInvalidos ex) {
            Logger.getLogger(PreparadorPizza.class.getName())
                  .log(Level.SEVERE, "Problema en la preparación de la Pizza", ex);
        }
    }

    public void prepararPizza(FabricaPizza fabrica, Ingrediente[] ingredientes)
            throws ExcepcionParametrosInvalidos {

        Amasador amasador = fabrica.crearAmasador();
        Moldeador moldeador = fabrica.crearMoldeador();
        Horneador horneador = fabrica.crearHorneador();

        amasador.amasar();
        moldeador.moldear();
        aplicarIngredientes(ingredientes);
        horneador.hornear();
    }

    private void aplicarIngredientes(Ingrediente[] ingredientes) {
        Logger.getLogger(PreparadorPizza.class.getName())
              .log(Level.INFO, "APLICANDO INGREDIENTES!: {0}", Arrays.toString(ingredientes));
    }
}

