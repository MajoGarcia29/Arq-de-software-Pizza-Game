
package edu.unisabana.pizzafactory.model;

/**
 *
 * @author cesarvefe
 */
public enum Tamano {
    
    MEDIANO, PEQUENO;
    
}
