package edu.unisabana.pizzafactory.model;

public interface Amasador {
    void amasar();
    
}
