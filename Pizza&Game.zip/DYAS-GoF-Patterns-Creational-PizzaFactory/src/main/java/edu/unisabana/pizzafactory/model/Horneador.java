package edu.unisabana.pizzafactory.model;

public interface Horneador {
    void hornear();
}

