package edu.unisabana.pizzafactory.model;

public class Ingrediente {
    private String nombre;
    private int cantidad;
    private String tipo;
    private String unidad;

    public Ingrediente(String nombre, int cantidad, String tipo, String unidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.unidad = unidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    @Override
    public String toString() {
        return "(" + nombre + ", " + cantidad + " " + unidad + ", tipo: " + tipo + ")";
    }
}

