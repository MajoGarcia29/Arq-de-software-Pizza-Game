package edu.unisabana.pizzafactory.model;

public interface Moldeador {
    void moldear();
}

