package edu.unisabana.pizzafactory.Fabricas;

import edu.unisabana.pizzafactory.model.*;

public interface FabricaPizza {
    Amasador crearAmasador();
    Moldeador crearMoldeador();
    Horneador crearHorneador();
}
