package com.balitechy.spacewar.main.renderers.vectorial;

import com.balitechy.spacewar.main.renderers.BackgroundRenderer;
import com.balitechy.spacewar.main.renderers.BulletRenderer;
import com.balitechy.spacewar.main.renderers.PlayerRenderer;
import com.balitechy.spacewar.main.renderers.RendererFactory;

public class VectorRendererFactory implements RendererFactory {

    @Override
    public PlayerRenderer createPlayerRenderer() {
        return new VectorPlayerRenderer();
    }

    @Override
    public BulletRenderer createBulletRenderer() {
        return new VectorBulletRenderer();
    }

    @Override
    public BackgroundRenderer createBackgroundRenderer() {
        return new VectorBackgroundRenderer();
    }
}
