package com.balitechy.spacewar.main.renderers.colorfulvectorial;

import com.balitechy.spacewar.main.renderers.BackgroundRenderer;
import com.balitechy.spacewar.main.renderers.BulletRenderer;
import com.balitechy.spacewar.main.renderers.PlayerRenderer;
import com.balitechy.spacewar.main.renderers.RendererFactory;

public class ColorfulVectorRendererFactory implements RendererFactory {

    @Override
    public PlayerRenderer createPlayerRenderer() {
        return new ColorfulVectorPlayerRenderer();
    }

    @Override
    public BulletRenderer createBulletRenderer() {
        return new ColorfulVectorBulletRenderer();
    }

    @Override
    public BackgroundRenderer createBackgroundRenderer() {
        return new ColorfulVectorBackgroundRenderer();
    }
}
