package com.balitechy.spacewar.main.renderers.sprite;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import com.balitechy.spacewar.main.SpritesImageLoader;
import com.balitechy.spacewar.main.renderers.BackgroundRenderer;

public class SpriteBackgroundRenderer implements BackgroundRenderer {

    private BufferedImage background;

    public SpriteBackgroundRenderer() {
        try {
            SpritesImageLoader loader = new SpritesImageLoader("/bg.png");
            loader.loadImage();
            background = loader.getImage(0, 0, 640, 480);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void render(Canvas canvas, Graphics g) {
        if (background != null) {
            g.drawImage(background, 0, 0, canvas.getWidth(), canvas.getHeight(), canvas);
        }
    }

    @Override
    public void render(Graphics g, Canvas canvas) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'render'");
    }
}