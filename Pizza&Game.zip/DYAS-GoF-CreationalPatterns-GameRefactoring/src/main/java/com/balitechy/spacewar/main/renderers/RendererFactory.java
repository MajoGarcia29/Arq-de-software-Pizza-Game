package com.balitechy.spacewar.main.renderers;

public interface RendererFactory {
    PlayerRenderer createPlayerRenderer();
    BulletRenderer createBulletRenderer();
    BackgroundRenderer createBackgroundRenderer();
}

