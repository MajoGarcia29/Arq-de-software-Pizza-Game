package com.balitechy.spacewar.main.renderers.vectorial;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

import com.balitechy.spacewar.main.renderers.BackgroundRenderer;

public class VectorBackgroundRenderer implements BackgroundRenderer {

    @Override
    public void render(Canvas canvas, Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    @Override
    public void render(Graphics g, Canvas canvas) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'render'");
    }
}

