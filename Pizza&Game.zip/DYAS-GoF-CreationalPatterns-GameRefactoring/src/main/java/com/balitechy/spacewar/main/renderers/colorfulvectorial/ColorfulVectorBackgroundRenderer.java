package com.balitechy.spacewar.main.renderers.colorfulvectorial;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

import com.balitechy.spacewar.main.renderers.BackgroundRenderer;


public class ColorfulVectorBackgroundRenderer implements BackgroundRenderer {

    @Override
    public void render(Graphics g, Canvas canvas) {
        g.setColor(Color.DARK_GRAY);
        g.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    @Override
    public void render(Canvas canvas, Graphics g) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'render'");
    }

}

