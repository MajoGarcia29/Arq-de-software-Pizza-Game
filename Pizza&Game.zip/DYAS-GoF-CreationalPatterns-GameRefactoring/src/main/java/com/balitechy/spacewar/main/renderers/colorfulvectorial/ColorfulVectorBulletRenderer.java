package com.balitechy.spacewar.main.renderers.colorfulvectorial;

import java.awt.Color;
import java.awt.Graphics;

import com.balitechy.spacewar.main.renderers.BulletRenderer;

public class ColorfulVectorBulletRenderer implements BulletRenderer {

    @Override
    public void render(Graphics g, int x, int y) {
        g.setColor(Color.RED);
        g.fillOval(x, y, 10, 10);

        g.setColor(Color.MAGENTA);
        g.drawOval(x, y, 10, 10);
    }
}