package com.balitechy.spacewar.main.renderers.sprite;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.balitechy.spacewar.main.SpritesImageLoader;
import com.balitechy.spacewar.main.renderers.PlayerRenderer;

public class SpritePlayerRenderer implements PlayerRenderer {

    private BufferedImage playerSprite;

    public SpritePlayerRenderer() {
        try {
            SpritesImageLoader loader = new SpritesImageLoader("/sprites.png");
            loader.loadImage();
            playerSprite = loader.getImage(0, 0, 30, 30);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void render(Graphics g, int x, int y) {
        if (playerSprite != null) {
            g.drawImage(playerSprite, x, y, null);
        }
    }
}
