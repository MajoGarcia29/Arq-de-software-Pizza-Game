package com.balitechy.spacewar.main.renderers;

import java.awt.Graphics;

public interface BulletRenderer {
    void render(Graphics g, int x, int y);
}

