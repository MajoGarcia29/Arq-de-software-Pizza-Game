package com.balitechy.spacewar.main.renderers;

import java.awt.Graphics;

public interface PlayerRenderer {
    void render(Graphics g, int x, int y);
}


