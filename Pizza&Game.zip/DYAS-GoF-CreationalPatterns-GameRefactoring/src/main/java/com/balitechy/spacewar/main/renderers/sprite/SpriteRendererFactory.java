package com.balitechy.spacewar.main.renderers.sprite;


import com.balitechy.spacewar.main.renderers.BackgroundRenderer;
import com.balitechy.spacewar.main.renderers.BulletRenderer;
import com.balitechy.spacewar.main.renderers.PlayerRenderer;
import com.balitechy.spacewar.main.renderers.RendererFactory;

public class SpriteRendererFactory implements RendererFactory {

    @Override
    public PlayerRenderer createPlayerRenderer() {
        return new SpritePlayerRenderer();
    }

    @Override
    public BulletRenderer createBulletRenderer() {
        return new SpriteBulletRenderer();
    }

    @Override
    public BackgroundRenderer createBackgroundRenderer() {
        return new SpriteBackgroundRenderer();
    }
}
