package com.balitechy.spacewar.main.renderers.sprite;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.balitechy.spacewar.main.SpritesImageLoader;
import com.balitechy.spacewar.main.renderers.BulletRenderer;

public class SpriteBulletRenderer implements BulletRenderer {

    private BufferedImage bulletSprite;

    public SpriteBulletRenderer() {
        try {
            SpritesImageLoader loader = new SpritesImageLoader("/sprites.png");
            loader.loadImage();
            bulletSprite = loader.getImage(30, 0, 10, 10); // Ajusta coordenadas según tu sprite
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void render(Graphics g, int x, int y) {
        if (bulletSprite != null) {
            g.drawImage(bulletSprite, x, y, null);
        }
    }
}
