package com.balitechy.spacewar.main;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;

import com.balitechy.spacewar.main.renderers.BackgroundRenderer;
import com.balitechy.spacewar.main.renderers.BulletRenderer;
import com.balitechy.spacewar.main.renderers.PlayerRenderer;
import com.balitechy.spacewar.main.renderers.RendererFactory;
import com.balitechy.spacewar.main.renderers.sprite.SpriteRendererFactory;
import com.balitechy.spacewar.main.renderers.vectorial.VectorRendererFactory;
import com.balitechy.spacewar.main.renderers.colorfulvectorial.ColorfulVectorRendererFactory;

public class Game extends Canvas implements Runnable {

    private static final long serialVersionUID = 1L;
    public static final int WIDTH = 320;
    public static final int HEIGHT = WIDTH / 12 * 9;
    public static final int SCALE = 2;
    public final String TITLE = "Space War 2D";

    private boolean running = false;
    private Thread thread;

    // Game state
    private int playerX = 100, playerY = 100;
    private int bulletX = 150, bulletY = 120;

    // Renderers
    private RendererFactory factory;
    private PlayerRenderer playerRenderer;
    private BulletRenderer bulletRenderer;
    private BackgroundRenderer backgroundRenderer;

    // Controladores de sprites y balas
    private SpritesImageLoader sprites;
    private BulletController bullets;

    public Game() {
        setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        setMaximumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        setMinimumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));

        // Estilo visual
        String style = "sprite";

        switch (style.toLowerCase()) {
            case "sprite":
                factory = new SpriteRendererFactory();
                break;
            case "vectorial":
                factory = new VectorRendererFactory();
                break;
            case "colorful-vectorial":
                factory = new ColorfulVectorRendererFactory();
                break;
            default:
                factory = new SpriteRendererFactory();
        }

        playerRenderer = factory.createPlayerRenderer();
        bulletRenderer = factory.createBulletRenderer();
        backgroundRenderer = factory.createBackgroundRenderer();

        // Inicializar controladores
        sprites = new SpritesImageLoader("/sprites.png");
        bullets = new BulletController();

        addKeyListener(new InputHandler(this));
        setFocusable(true);
        requestFocus();
    }

    private synchronized void start() {
        if (running) return;
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    private synchronized void stop() {
        if (!running) return;
        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        final double ticksPerSecond = 60.0;
        double ns = 1_000_000_000 / ticksPerSecond;
        double delta = 0;

        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;

            while (delta >= 1) {
                tick();
                delta--;
            }
            render();
        }
        stop();
    }

    private void tick() {
        bullets.tick();
    }

    private void render() {
        BufferStrategy bs = getBufferStrategy();
        if (bs == null) {
            createBufferStrategy(3);
            return;
        }

        Graphics g = bs.getDrawGraphics();

        g.clearRect(0, 0, getWidth(), getHeight());

        backgroundRenderer.render(this, g);
        playerRenderer.render(g, playerX, playerY);
        bulletRenderer.render(g, bulletX, bulletY);

        bullets.render(g);

        g.dispose();
        bs.show();
    }

    public void movePlayer(int dx, int dy) {
        playerX += dx;
        playerY += dy;
    }

    public void shootBullet(int x, int y) {
        bulletX = x;
        bulletY = y;
    }

    public static void main(String[] args) {
        Game game = new Game();

        JFrame frame = new JFrame(game.TITLE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.add(game);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        game.start();
    }

    public SpritesImageLoader getSprites() {
        return sprites;
    }

    public BulletController getBullets() {
        return bullets;
    }

    // Métodos de control de teclado
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        switch (key) {
            case KeyEvent.VK_W:
            case KeyEvent.VK_UP:
                movePlayer(0, -5);
                break;
            case KeyEvent.VK_S:
            case KeyEvent.VK_DOWN:
                movePlayer(0, 5);
                break;
            case KeyEvent.VK_A:
            case KeyEvent.VK_LEFT:
                movePlayer(-5, 0);
                break;
            case KeyEvent.VK_D:
            case KeyEvent.VK_RIGHT:
                movePlayer(5, 0);
                break;
            case KeyEvent.VK_SPACE:
                bullets.addBullet(null);
                break;
        }
    }

    public void keyReleased(KeyEvent e) {
        // Aquí puedes implementar la lógica cuando se suelta la tecla si es necesario.
        // Por ejemplo, detener el movimiento continuo si lo manejas así.
    }
}
