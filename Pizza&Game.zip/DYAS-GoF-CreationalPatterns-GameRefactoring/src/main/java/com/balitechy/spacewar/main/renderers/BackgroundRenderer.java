package com.balitechy.spacewar.main.renderers;

import java.awt.Canvas;
import java.awt.Graphics;

public interface BackgroundRenderer {
    void render(Canvas canvas, Graphics g);

    void render(Graphics g, Canvas canvas);
}


