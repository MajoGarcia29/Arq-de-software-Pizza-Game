package com.balitechy.spacewar.main.renderers.vectorial;

import java.awt.Color;
import java.awt.Graphics;

import com.balitechy.spacewar.main.renderers.PlayerRenderer;

public class VectorPlayerRenderer implements PlayerRenderer {

    @Override
    public void render(Graphics g, int x, int y) {
        g.setColor(Color.WHITE);
        g.fillOval(x, y, 30, 30);

        g.setColor(Color.BLACK);
        g.drawOval(x, y, 30, 30);

        g.drawLine(x + 15, y + 15, x + 15, y);
    }
}
