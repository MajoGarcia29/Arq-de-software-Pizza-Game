package com.balitechy.spacewar.main.renderers.colorfulvectorial;

import java.awt.Color;
import java.awt.Graphics;

import com.balitechy.spacewar.main.renderers.PlayerRenderer;

public class ColorfulVectorPlayerRenderer implements PlayerRenderer {

    @Override
    public void render(Graphics g, int x, int y) {
        g.setColor(Color.CYAN);
        g.fillOval(x, y, 30, 30);

        g.setColor(Color.BLUE);
        g.drawOval(x, y, 30, 30);

        g.setColor(Color.YELLOW);
        g.fillRect(x + 10, y + 5, 10, 5);

        g.setColor(Color.ORANGE);
        g.fillRect(x + 12, y + 30, 6, 10);
    }
}
