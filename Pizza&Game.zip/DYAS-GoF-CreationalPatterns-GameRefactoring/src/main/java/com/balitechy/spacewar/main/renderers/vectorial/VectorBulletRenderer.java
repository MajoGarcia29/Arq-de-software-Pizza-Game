package com.balitechy.spacewar.main.renderers.vectorial;

import java.awt.Color;
import java.awt.Graphics;

import com.balitechy.spacewar.main.renderers.BulletRenderer;

public class VectorBulletRenderer implements BulletRenderer {

    @Override
    public void render(Graphics g, int x, int y) {
        g.setColor(Color.WHITE);
        g.fillOval(x, y, 10, 10);

        g.setColor(Color.BLACK);
        g.drawOval(x, y, 10, 10);
    }
}
